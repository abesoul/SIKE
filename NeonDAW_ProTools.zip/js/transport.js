// transport.js - module placeholder
