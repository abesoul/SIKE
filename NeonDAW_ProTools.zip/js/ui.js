// ui.js - module placeholder
